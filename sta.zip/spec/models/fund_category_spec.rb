require 'spec_helper'

describe FundCategory do
  pending "add some examples to (or delete) #{__FILE__}"
end
