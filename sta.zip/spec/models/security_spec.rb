require 'spec_helper'

describe Security do
  pending "add some examples to (or delete) #{__FILE__}"
end
