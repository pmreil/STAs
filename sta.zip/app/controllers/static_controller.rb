class StaticController < ApplicationController
  def about
  end

  def contact
  end

end
