# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Sta::Application.config.secret_token = 'ce3c9c6cd60afdc6292f000dd3a44fcb4002235b608af4d69ba1dfb7273033cad476d462ceb204b21bcfa82e22d6954e7178c5561f9a51035df2a8fbc8f3a8ab'
